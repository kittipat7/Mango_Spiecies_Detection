# Mango Detection > 2022-12-25 10:38pm
https://universe.roboflow.com/object-detection/mango-detection-vuz8m

Provided by a Roboflow user
License: CC BY 4.0

